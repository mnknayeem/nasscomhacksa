//
// mnk
//

#ifndef neond_THING_H
#define neond_THING_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>


#define my  me ->
#define your  you ->
#define our  us ->

#define strequ  ! strcmp
#define strnequ  ! strncmp

#ifdef __cplusplus
}
#endif

#endif //neond_THING_H
