//
// mnk
//

#ifndef neond_NeonEXCEPTION_H
#define neond_NeonEXCEPTION_H

#ifdef __cplusplus
extern "C" {
#endif

#include <jni.h>

void throwNeonException(
        JNIEnv *env,
        const char *functionName,
        const char *file,
        const int line,
        const int code,
        const char *message
);


void  throwNeonException(
        JNIEnv *env,
        const char *functionName,
        const char *file,
        const int line,
        const int code,
        const char *message
)
{
    // Find and instantiate a NeonException
    jclass exClass =
            env->FindClass ("com/projects/alshell/Neon/NeonException");

    jmethodID constructor =
            env->GetMethodID (exClass, "<init>",
                              "(ILjava/lang/String;)V");

    jobject exception = env->NewObject (exClass, constructor,
                                        code,
                                        env->NewStringUTF (message));


    // Find the __jni_setLocation method and call it with
    // the function name, file and line parameters
    jmethodID setLocation =
            env->GetMethodID (exClass, "__jni_setLocation",
                              "(Ljava/lang/String;"
                                      "Ljava/lang/String;"
                                      "I)V");

    env->CallVoidMethod (exception, setLocation,
                         env->NewStringUTF (functionName),
                         env->NewStringUTF (file),
                         line);

    // Throw the exception. Since this is native code,
    // execution continues, and the execution will be abruptly
    // interrupted at the point in time when we return to the VM.
    // The calling code will perform the early return back to Java code.
    env->Throw ((jthrowable) exception);

    // Clean up local reference
    env->DeleteLocalRef (exClass);
}

#define ThrowNeonException(code, message) throwNeonException(env, __func__, __FILE__, __LINE__, code, message)

#ifdef __cplusplus
}
#endif
#endif //neond_NeonEXCEPTION_H
