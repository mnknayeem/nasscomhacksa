//
// mnk
//

#ifndef neond_Neon_H
#define neond_Neon_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct structNeonVoice *NeonVoice;

NeonVoice NeonVoice_create (
        double sample_rate,
        int buffer_length
);

typedef struct {
    double neutrality;
    double happiness;
    double sadness;
    double anger;
    double fear;
} NeonEmotionProbabilities;

void NeonVoice_setRelativePriorProbabilities (
        NeonVoice voice,
        NeonEmotionProbabilities *priorEmotionProbabilities
);

void NeonVoice_fill (
        NeonVoice voice,
        int num_samples,
        double samples []
);

typedef struct {
    int valid;   // 1 = "there were voiced frames, so that the measurements are valid"; 0 = "no voiced frames found"
    int num_frames_analyzed;
    int num_frames_lost;
} NeonQuality;

void NeonVoice_extract (
        NeonVoice voice,
        NeonQuality *quality,
        NeonEmotionProbabilities *emotionProbabilities
);

void NeonVoice_destroy (NeonVoice voice);

void NeonVoice_reset (NeonVoice voice);

const char *Neon_versionAndLicense ();

#ifdef __cplusplus
}
#endif
#endif //neond_Neon_H
