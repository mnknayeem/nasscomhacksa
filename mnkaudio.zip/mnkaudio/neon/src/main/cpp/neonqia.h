//
// mnk
//

#ifndef neond_NeonQUALITY_H
#define neond_NeonQUALITY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "Thing.h"
#include "Neon.h"

inline static void NeonQuality_error (NeonQuality *me) {
    my valid = false;
    my num_frames_analyzed = 0;
    my num_frames_lost = 0;
}

#ifdef __cplusplus
}
#endif

#endif //neond_NeonQUALITY_H
