//
// mnk
//

#ifndef neond_Neon9_H
#define neond_Neon9_H
#ifdef __cplusplus
extern "C" {
#endif

#include "Neon.h"
#include "Cues9.h"

void NeonVoice_extractCues9 (NeonVoice me, NeonQuality *quality, CueStrengths9 cueStrengths);


#ifdef __cplusplus
}
#endif
#endif //neond_Neon9_H
